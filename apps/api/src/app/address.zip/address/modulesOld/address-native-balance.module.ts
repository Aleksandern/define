import { Injectable } from '@nestjs/common';

import {
  formatUnits,
} from 'viem';

import { RpcClientFactory } from '@appApi/app/rpc/rpc-client.factory';

import { ADDRESS_MODULES } from '../constants';
import type {
  AddressModuleResultT,
  AddressModuleT,
} from '../types';
import { isChainActive } from '../utils';

interface NativeBalanceDataT {
  symbol: string,
  decimals: number,
  balanceWei: string,
  balance: string,
}

@Injectable()
export class AddressNativeBalanceModule implements AddressModuleT {
  readonly key = ADDRESS_MODULES.nativeBalance;

  constructor(private readonly rpcClientFactory: RpcClientFactory) {}

  async run({
    address,
    chain,
    ctx,
  }: Parameters<AddressModuleT['run']>[0]): Promise<AddressModuleResultT<NativeBalanceDataT> | null> {
    const res: AddressModuleResultT<NativeBalanceDataT> = {
      key: this.key,
      chain,
      status: 'error',
    };

    const canRun = isChainActive({ ctx });
    if (!canRun) {
      return null;
    }

    try {
      const client = await this.rpcClientFactory.getClient({
        chainIdOrig: chain.chainIdOrig,
      });

      const wei = await client.getBalance({ address });

      // take symbol/decimals from chainCtx (from DB), if not — fallback
      const symbol = chain.nativeSymbol ?? 'NATIVE';
      const decimals = typeof chain.nativeDecimals === 'number' ? chain.nativeDecimals : 18;

      res.status = 'ok';
      res.data = {
        symbol,
        decimals,
        balanceWei: wei.toString(),
        balance: formatUnits(wei, decimals),
      };
    } catch (e) {
      res.status = 'error';
      res.error = e instanceof Error ? e.message : String(e);
    }

    return res;
  }
}
